import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { AuthProvider } from './context/AuthContext';
import { PlanProvider } from './context/planContext';
import { ThemeContextProvider, useAppTheme } from './context/ThemeContext';
import ProtectedRoute from './components/ProtectedRoute';
import Navbar from './components/Navbar';
import PermanentSidebar from './components/PermanentSidebar';
import CustomCursor from './components/CustomCursor';
import { TrialBanner, FreePlanUpgradeModal } from './components/plan';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import { useEffect, useMemo, useState } from 'react';

import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Clientes from './pages/Clientes';
import ClienteForm from './pages/ClienteForm';
import Productos from './pages/Productos';
import ProductoForm from './pages/ProductoForm';
import Ventas from './pages/Ventas';
import VentaForm from './pages/VentaForm';
import VentaDetalle from './pages/VentaDetalle';
import Eventos from './pages/Eventos';
import EventosPremium from './pages/EventosPremium';
import GestionEventoPremium from './pages/GestionEventoPremium';
import ConsecutivoNavigation from './pages/consecutivo/ConsecutivoNavigation';
import Usuarios from './pages/Usuarios';
import Roles from './pages/Roles';
import Cotizaciones from './pages/Cotizaciones';
import CotizacionDetalle from './pages/CotizacionDetalle';
import DisponibilidadProducto from './pages/DisponibilidadProducto';
import EmpresasAdmin from './pages/EmpresasAdmin';
import EmpresaPendiente from './pages/EmpresaPendiente';
import SuperAdminDashboard from './pages/SuperAdminDashboard';
import Configuraciones from './pages/Configuraciones';
import Planes from './pages/Planes';
import Checkout from './pages/Checkout';
import PagoExito from './pages/PagoExito';
import PagoError from './pages/PagoError';

// Construye el tema MUI dinámicamente a partir del tema activo (currentThemeTokens)
// y el modo resuelto (resolvedMode), ambos provenientes del ThemeContext.
function AppWithTheme({ children }) {
  const { currentThemeTokens: tokens, resolvedMode: mode } = useAppTheme();

  const theme = useMemo(
    () =>
      createTheme({
        palette: {
          mode,
          primary: tokens.primary,
          secondary: tokens.secondary,
          success: tokens.success,
          warning: tokens.warning,
          error: tokens.error,
          info: tokens.info,
          accent: { main: '#49BEFF' },
          neutral: { main: '#64748B' },
          ...(mode === 'light'
            ? {
                background: { default: tokens.light.bgDefault, paper: tokens.light.bgPaper },
                text: { primary: tokens.light.textPrimary, secondary: tokens.light.textSecondary },
                divider: 'rgba(145, 158, 171, 0.24)',
              }
            : {
                background: { default: tokens.dark.bgDefault, paper: tokens.dark.bgPaper },
                text: { primary: tokens.dark.textPrimary, secondary: tokens.dark.textSecondary },
                divider: 'rgba(145, 158, 171, 0.24)',
              }),
        },
        shape: { borderRadius: 12 },
        typography: {
          fontFamily: ['Inter', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'].join(','),
          h1: { fontWeight: 700 },
          h2: { fontWeight: 700 },
          h3: { fontWeight: 700 },
          button: { textTransform: 'none', fontWeight: 600 },
        },
        components: {
          MuiAppBar: {
            styleOverrides: {
              root: {
                background: tokens.appBarGradient,
                color: '#ffffff',
                backdropFilter: 'blur(10px)',
                WebkitBackdropFilter: 'blur(10px)',
                boxShadow: 'none',
                borderBottom: '1px solid rgba(255,255,255,0.10)',
              },
            },
          },
          MuiPaper: {
            defaultProps: { elevation: 1 },
            styleOverrides: {
              root: ({ theme }) => ({
                borderRadius: 12,
                border:
                  theme.palette.mode === 'light'
                    ? '1px solid #eef2f6'
                    : '1px solid rgba(255,255,255,0.06)',
              }),
            },
          },
          MuiCard: {
            styleOverrides: {
              root: ({ theme }) => ({
                boxShadow:
                  theme.palette.mode === 'light'
                    ? '0 2px 8px rgba(16,24,40,0.06)'
                    : '0 2px 8px rgba(0,0,0,0.35)',
              }),
            },
          },
          MuiButton: {
            styleOverrides: {
              root: { borderRadius: 10, paddingInline: 16, paddingBlock: 8, boxShadow: 'none' },
              containedPrimary: { boxShadow: '0 6px 16px rgba(93,135,255,0.35)' },
              containedSecondary: { boxShadow: '0 6px 16px rgba(138,93,255,0.35)' },
              containedSuccess: { boxShadow: '0 6px 16px rgba(19,222,185,0.35)' },
            },
          },
          MuiDrawer: {
            styleOverrides: {
              paper: {
                backgroundColor: mode === 'dark' ? tokens.dark.sidebarBg : tokens.light.sidebarBg,
                color: mode === 'dark' ? tokens.dark.textPrimary : tokens.light.textPrimary,
                backdropFilter: mode === 'dark' ? tokens.dark.sidebarBackdropFilter : 'none',
              },
            },
          },
        },
      }),
    [tokens, mode]
  );

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      {children}
    </ThemeProvider>
  );
}

const GlobalWatermark = () => {
  const location = useLocation();
  const isAuthPage = location.pathname === '/login' || location.pathname === '/register';
  
  return (
    <img 
      src={isAuthPage ? "/LogoFondoLogin.png" : "/logo.png"} 
      alt="Marca de agua" 
      className="global-watermark" 
      style={isAuthPage ? { borderRadius: '24px' } : {}}
    />
  );
};

// Componente que muestra el TrialBanner cuando es necesario, y aplica una
// transición de fade suave (estilo cambio de diapositiva) cada vez que
// cambia de pantalla.
const AppContent = ({ children }) => {
  const [showTrialBanner, setShowTrialBanner] = useState(true);
  const location = useLocation();
  const isAuthPage = location.pathname === '/login' || location.pathname === '/register';

  if (isAuthPage) {
    return (
      <Box key={location.pathname} className="app-page-transition" sx={{ width: '100%' }}>
        {children}
      </Box>
    );
  }

  return (
    <Box sx={{ width: '100%' }}>
      <FreePlanUpgradeModal />
      {showTrialBanner && (
        <TrialBanner 
          onClose={() => setShowTrialBanner(false)} 
          variant="filled"
        />
      )}
      <Box key={location.pathname} className="app-page-transition">
        {children}
      </Box>
    </Box>
  );
};

function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => {
    return localStorage.getItem('sidebar-collapsed') === '1';
  });

  useEffect(() => {
    localStorage.setItem('sidebar-collapsed', sidebarCollapsed ? '1' : '0');
  }, [sidebarCollapsed]);

  // Sidebar width
  const drawerWidth = 272;

  return (
    <ThemeContextProvider>
      <AppWithTheme>
        <CustomCursor />
        <Router>
          <AuthProvider>
            <PlanProvider>
              <Box sx={{ display: 'flex', minHeight: '100vh' }}>
                <Navbar
                  sidebarCollapsed={sidebarCollapsed}
                  onToggleSidebarCollapsed={() => setSidebarCollapsed((p) => !p)}
                />
              <PermanentSidebar width={drawerWidth} collapsed={sidebarCollapsed} />
              <Box
                component="main"
                className="print-main main-watermark-wrapper"
                sx={{
                  flexGrow: 1,
                  minWidth: 0,
                  mt: '64px', // Altura del AppBar
                  display: 'flex',
                  flexDirection: 'column',
                }}
              >
                {/* Marca de agua global detras del contenido */}
                <GlobalWatermark />

                <AppContent>
                  <Container maxWidth={false} disableGutters sx={{ py: 2, px: 0 }} className="with-watermark-content">
                    <Routes>
                      <Route path="/login" element={<Login />} />
                      <Route path="/register" element={<Register />} />
                      <Route path="/empresa-pendiente" element={<EmpresaPendiente />} />
                      
                      <Route path="/" element={
                        <ProtectedRoute>
                          <Dashboard />
                        </ProtectedRoute>
                      } />
                      
                      <Route path="/dashboard" element={
                        <ProtectedRoute>
                          <Dashboard />
                        </ProtectedRoute>
                      } />
                      <Route path="/superadmin/dashboard" element={
                        <ProtectedRoute>
                          <SuperAdminDashboard />
                        </ProtectedRoute>
                      } />
                      
                      {/* Rutas de Clientes */}
                      <Route path="/clientes" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'clientes', accion: 'ver' }}>
                          <Clientes />
                        </ProtectedRoute>
                      } />
                      <Route path="/clientes/nuevo" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'clientes', accion: 'crear' }}>
                          <ClienteForm />
                        </ProtectedRoute>
                      } />
                      <Route path="/clientes/editar/:id" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'clientes', accion: 'editar' }}>
                          <ClienteForm />
                        </ProtectedRoute>
                      } />
                      
                      {/* Rutas de Productos */}
                      <Route path="/productos" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'productos', accion: 'ver' }}>
                          <Productos />
                        </ProtectedRoute>
                      } />
                      <Route path="/productos/nuevo" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'productos', accion: 'crear' }}>
                          <ProductoForm />
                        </ProtectedRoute>
                      } />
                      <Route path="/productos/editar/:id" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'productos', accion: 'editar' }}>
                          <ProductoForm />
                        </ProtectedRoute>
                      } />
                      
                      {/* Rutas de Ventas */}
                      <Route path="/ventas" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'ventas', accion: 'ver' }}>
                          <Ventas />
                        </ProtectedRoute>
                      } />
                      <Route path="/ventas/nueva" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'ventas', accion: 'crear' }}>
                          <VentaForm />
                        </ProtectedRoute>
                      } />
                      <Route path="/ventas/editar/:id" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'ventas', accion: 'editar' }}>
                          <VentaForm />
                        </ProtectedRoute>
                      } />
                      <Route path="/ventas/ver/:id" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'ventas', accion: 'ver' }}>
                          <VentaDetalle />
                        </ProtectedRoute>
                      } />

                      {/* Rutas de Consecutivos */}
                      <Route path="/consecutivos" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'consecutivos', accion: 'ver' }}>
                          <ConsecutivoNavigation />
                        </ProtectedRoute>
                      } />

                      {/* Rutas de Eventos */}
                      <Route path="/eventos" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'eventos', accion: 'ver' }}>
                          <Eventos />
                        </ProtectedRoute>
                      } />
                      <Route path="/eventos-premium" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'eventosPremium', accion: 'ver' }}>
                          <EventosPremium />
                        </ProtectedRoute>
                      } />
                      <Route path="/eventos-premium/:id/gestion" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'eventosPremium', accion: 'editar' }}>
                          <GestionEventoPremium />
                        </ProtectedRoute>
                      } />

                      {/* Rutas de Usuarios (solo admin, backend valida) */}
                      <Route path="/usuarios" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'usuarios', accion: 'ver' }}>
                          <Usuarios />
                        </ProtectedRoute>
                      } />

                      {/* Rutas de Roles (solo admin, backend valida) */}
                      <Route path="/roles" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'roles', accion: 'ver' }}>
                          <Roles />
                        </ProtectedRoute>
                      } />

                      {/* Rutas de Cotizaciones */}
                      <Route path="/cotizaciones" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'cotizaciones', accion: 'ver' }}>
                          <Cotizaciones />
                        </ProtectedRoute>
                      } />
                      <Route path="/cotizaciones/ver/:id" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'cotizaciones', accion: 'ver' }}>
                          <CotizacionDetalle />
                        </ProtectedRoute>
                      } />

                      {/* Rutas de Disponibilidad de Productos */}
                      <Route path="/disponibilidad" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'disponibilidad', accion: 'ver' }}>
                          <DisponibilidadProducto />
                        </ProtectedRoute>
                      } />

                      {/* Rutas de Superadmin */}
                      <Route path="/superadmin/empresas" element={
                        <ProtectedRoute>
                          <EmpresasAdmin />
                        </ProtectedRoute>
                      } />

                      <Route path="/configuraciones" element={
                        <ProtectedRoute requiredPermission={{ modulo: 'configuracion', accion: 'ver' }}>
                          <Configuraciones />
                        </ProtectedRoute>
                      } />

                      {/* Ruta de Planes */}
                      <Route path="/planes" element={
                        <ProtectedRoute>
                          <Planes />
                        </ProtectedRoute>
                      } />
                      <Route path="/checkout" element={
                        <ProtectedRoute>
                          <Checkout />
                        </ProtectedRoute>
                      } />
                      <Route path="/pago/exito" element={
                        <ProtectedRoute>
                          <PagoExito />
                        </ProtectedRoute>
                      } />
                      <Route path="/pago/error" element={
                        <ProtectedRoute>
                          <PagoError />
                        </ProtectedRoute>
                      } />
                    </Routes>
                  </Container>
                </AppContent>
              </Box>
            </Box>
            <ToastContainer position="bottom-right" />
            </PlanProvider>
          </AuthProvider>
        </Router>
      </AppWithTheme>
    </ThemeContextProvider>
  );
}

export default App;
